// 
// import { Link } from "react-router-dom" //useParams
// import { BLOG_POSTS } from "../components/data/blogs"

export default function BlogDetailPage() {
// //   const { slug } = useParams()
//   const post = BLOG_POSTS.find((p: any)=>) //  p.slug === slug

//   if (!post) {
//     return (
//       <div className="container mx-auto px-4 py-20 text-center">
//         <h1 className="text-3xl font-extrabold text-neutral-900">We are sorry, page not found!</h1>
//         <p className="mt-2 text-neutral-600">
//           The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
//         </p>
//         <Link
//           to="/blogs"
//           className="inline-block mt-6 rounded bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700"
//         >
//           Back to Blog
//         </Link>
//       </div>
//     )
//   }

//   return (
//     <article className="bg-white">
//       <header className="border-b border-neutral-200">
//         <div className="container mx-auto px-4 py-6">
//           <nav className="text-xs text-neutral-500">
//             Home / Blogs / <span className="text-neutral-800">{post.title}</span>
//           </nav>
//           <h1 className="mt-2 text-2xl md:text-3xl font-extrabold text-neutral-900 text-pretty">{post.title}</h1>
//           <div className="mt-2 flex items-center gap-2 text-[12px] text-neutral-500">
//             <span className="uppercase tracking-wide">{post.category}</span>
//             <span>•</span>
//             <span>{post.date}</span>
//             <span>•</span>
//             <span>{post.readTime}</span>
//           </div>
//         </div>
//       </header>

//       <div className="container mx-auto px-4 py-8">
//         <img
//           src={post.image || "/placeholder.svg?height=260&width=1000&query=Blog%20cover"}
//           alt=""
//           className="w-full h-64 object-cover rounded-md"
//         />

//         <div className="prose prose-neutral max-w-none mt-6">
//           <p className="text-neutral-700 leading-relaxed">{post.content}</p>
//           <p className="text-neutral-700 leading-relaxed mt-4">
//             Note: This is a demo article layout. Replace with your CMS or real content as needed.
//           </p>
//         </div>

//         <div className="mt-10">
//           <Link
//             to="/blogs"
//             className="inline-block rounded bg-neutral-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-neutral-800"
//           >
//             Back to all posts
//           </Link>
//         </div>
//       </div>
//     </article>
//   )
}
